# Indeed Job Scraper
 A web scraper to extract job postings from www.indeed.com

**Check out the tutorial on [YouTube](https://youtu.be/eN_3d4JrL_w)**

![](data-example.png)
